  function displayResult(resultMatrix) {
    const resultTable = document.getElementById('result');
    resultTable.innerHTML = '';

    // Add a CSS class to the result table
    resultTable.classList.add('result-table');
    

    for (let i = 0; i < resultMatrix.length; i++) {
      const row = document.createElement('tr');

      for (let j = 0; j < resultMatrix[i].length; j++) {
        const cell = document.createElement('td');
        cell.innerText = resultMatrix[i][j];
        row.appendChild(cell);
      }

      resultTable.appendChild(row);
    }
  }

  function getMatrixValues(tableId) {
    const table = document.getElementById(tableId);
    const rows = table.getElementsByTagName('tr');
    const matrix = [];

    for (let i = 0; i < rows.length; i++) {
      const cells = rows[i].getElementsByTagName('td');
      const row = [];

      for (let j = 0; j < cells.length; j++) {
        const value = parseInt(cells[j].querySelector('.input-cell').value);
        row.push(value);
      }

      matrix.push(row);
    }

    return matrix;
  }

  function addMatrices() {
    const matrixA = getMatrixValues('matrixA');
    const matrixB = getMatrixValues('matrixB');

    if (matrixA.length !== 3 || matrixB.length !== 3) {
      console.log('Invalid matrices');
      return;
    }

    const resultMatrix = [];

    for (let i = 0; i < matrixA.length; i++) {
      const row = [];

      for (let j = 0; j < matrixA[i].length; j++) {
        const sum = matrixA[i][j] + matrixB[i][j];
        row.push(sum);
      }

      resultMatrix.push(row);
    }

    displayResult(resultMatrix);
  }

  function subtractMatrices() {
    const matrixA = getMatrixValues('matrixA');
    const matrixB = getMatrixValues('matrixB');

    if (matrixA.length !== 3 || matrixB.length !== 3) {
      console.log('Invalid matrices');
      return;
    }

    const resultMatrix = [];

    for (let i = 0; i < matrixA.length; i++) {
      const row = [];

      for (let j = 0; j < matrixA[i].length; j++) {
        const diff = matrixA[i][j] - matrixB[i][j];
        row.push(diff);
      }

      resultMatrix.push(row);
    }

    displayResult(resultMatrix);
  }

  function multiplyMatrices() {
    const matrixA = getMatrixValues('matrixA');
    const matrixB = getMatrixValues('matrixB');

    if (matrixA.length !== 3 || matrixB.length !== 3) {
      console.log('Invalid matrices');
      return;
    }

    const resultMatrix = [];

    for (let i = 0; i < matrixA.length; i++) {
      const row = [];

      for (let j = 0; j < matrixB[0].length; j++) {
        let sum = 0;

        for (let k = 0; k < matrixB.length; k++) {
          sum += matrixA[i][k] * matrixB[k][j];
        }

        row.push(sum);
      }

      resultMatrix.push(row);
    }

    displayResult(resultMatrix);
  }

  function resetMatrices() {
    // Clear the result table
    const resultTable = document.getElementById('result');
    resultTable.innerHTML = '';

    // Change all the values in the result table to 0
    const inputCells = document.getElementsByClassName('input-cell');
    for (let i = 0; i < inputCells.length; i++) {
      inputCells[i].value = '';
    }

    // Create a result matrix filled with 0 values
    const resultMatrix = [];
    const matrixSize = 3; // Assuming the matrix size is always 3x3

    for (let i = 0; i < matrixSize; i++) {
      const row = [];

      for (let j = 0; j < matrixSize; j++) {
        row.push(0);
      }

      resultMatrix.push(row);
    }

    // Display the result matrix with all 0 values
    displayResult(resultMatrix);
  }